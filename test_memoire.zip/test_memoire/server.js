import express from 'express';
import userLoginSignup from './routers/userLoginSignup.js';
import vacateurRouters from './routers/vacateurRouters.js';
import { EventEmitter } from 'events';
import 'dotenv/config';



const server = express();
server.use(express.json());


EventEmitter.defaultMaxListeners = 20;

server.use('/user',userLoginSignup);
server.use('/vacateur', vacateurRouters);
const port = process.env.PORT || 6000;
 

server.listen(port , () => {
    console.log(`server is running in ${port}`);
})

