import express from 'express';
import {vacateurInscrir,supprimerVacateur} from'../controllers/vacateurController.js';


const router = express.Router();


router.post('/inscrir',vacateurInscrir);
router.delete('/supprimer',supprimerVacateur);

export default router;